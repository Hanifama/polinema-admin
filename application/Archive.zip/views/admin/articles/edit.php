<?php $this->load->view('admin/template/header'); ?>

<!--  BO :heading -->
<div class="row wrapper border-bottom white-bg page-heading">
  <div class="col-sm-4 m-2">
    <h2>Articles</h2>

    <ol class="breadcrumb">
      <li>
        <a href="<?php echo base_url() . 'admin/' ?>">Dashboard</a>
      </li>
      <li class="active">
        <strong>Articles</strong>
      </li>
    </ol>
  </div>

  <div class="col-sm-8">
    <div class="title-action">
    </div>
  </div>
</div>

<!--  EO :heading -->
<div class="row">
  <div class="animated fadeInRight">
    <div class="ibox card ">
      <div class="ibox-title card-header">
        <h5> Edit <small></small></h5>
        <div class="ibox-tools">
        </div>
      </div>
      <!-- ............................................................. -->

      <!-- BO : content  -->
      <div class="col-sm-12 white-bg card-body ">
        <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title"> </h3>
          </div>
          <!-- /.box-header -->

          <!-- form start -->
          <form action="" id="" class="form-horizontal " method="post" enctype="multipart/form-data">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
            <div class="box-body">

              <?php if ($this->session->flashdata('message')): ?>
                <div class="alert alert-success">
                  <button type="button" class="close" data-close="alert"></button>
                  <?php echo $this->session->flashdata('message'); ?>
                </div>
              <?php endif; ?>              <!-- ID Start -->

              <div class="form-group mb-3">
                <label for="article_id" class="col-sm-3 form-label"> ID </label>
                <div class="col-sm-6">
                  <input type="text" class="form-control" id="article_id" name="article_id" value="<?php echo set_value("article_id", html_entity_decode($articles->article_id)); ?>">
                </div>
                <div class="col-sm-4">
                  <?php echo form_error("article_id", "<span class='label label-danger'>", "</span>") ?>
                </div>

              </div>

              <!-- ID End -->

              <!-- Title Start -->

              <div class="form-group mb-3">
                <label for="title" class="col-sm-3 form-label"> Title </label>
                <div class="col-sm-6">
                  <input type="text" class="form-control" id="title" name="title" value="<?php echo set_value("title", html_entity_decode($articles->title)); ?>">
                </div>
                <div class="col-sm-4">
                  <?php echo form_error("title", "<span class='label label-danger'>", "</span>") ?>
                </div>

              </div>

              <!-- Title End -->

              <!-- Slug Start -->

              <div class="form-group mb-3">
                <label for="slug" class="col-sm-3 form-label"> Slug </label>
                <div class="col-sm-6">
                  <input type="text" class="form-control" id="slug" name="slug" value="<?php echo set_value("slug", html_entity_decode($articles->slug)); ?>">
                </div>
                <div class="col-sm-4">
                  <?php echo form_error("slug", "<span class='label label-danger'>", "</span>") ?>
                </div>

              </div>

              <!-- Slug End -->              <!-- Content Start -->

              <div class="form-group mb-3">
                <label for="content" class="col-sm-3 form-label"> Content </label>
                <div class="col-sm-6">
                  <textarea class="form-control" id="content" name="content"><?php echo set_value("content", html_entity_decode($articles->content)); ?></textarea>
                </div>
                <div class="col-sm-4">
                  <?php echo form_error("content", "<span class='label label-danger'>", "</span>") ?>
                </div>
              </div>

              <!-- Content End -->              <!-- Author Start -->

              <div class="form-group mb-3">
                <label for="author" class="col-sm-3 form-label"> Author </label>
                <div class="col-sm-6">
                  <input type="text" class="form-control" id="author" name="author" value="<?php echo set_value("author", html_entity_decode($articles->author)); ?>">
                </div>
                <div class="col-sm-4">
                  <?php echo form_error("author", "<span class='label label-danger'>", "</span>") ?>
                </div>

              </div>

              <!-- Author End -->

              <!-- Published_by Start -->

              <div class="form-group mb-3">
                <label for="published_by" class="col-sm-3 form-label"> Published_by </label>
                <div class="col-sm-6">
                  <input type="text" class="form-control" id="published_by" name="published_by" value="<?php echo set_value("published_by", html_entity_decode($articles->published_by)); ?>">
                </div>
                <div class="col-sm-4">
                  <?php echo form_error("published_by", "<span class='label label-danger'>", "</span>") ?>
                </div>

              </div>

              <!-- Published_by End -->

              <!-- Published_dt Start -->

              <div class="form-group mb-3">
                <label for="published_dt" class="col-sm-3 form-label"> Published_dt </label>
                <div class="col-sm-6">
                  <input type="text" class="form-control datetimepicker" name="published_dt" id="published_dt" value="<?php echo set_value("published_dt", $articles->published_dt); ?>" />
                </div>
                <div class="col-sm-4">
                  <?php echo form_error("published_dt", "<span class='label label-danger'>", "</span>") ?>
                </div>
              </div>

              <!-- Published_dt End -->

              <!-- Image Start -->

              <div class="form-group mb-3">

                <label for="address" class="col-sm-3 form-label"> Image </label>

                <div class="col-sm-6">

                  <input type="file" name="image" />

                  <input type="hidden" name="old_image"

                    value="<?php if (isset($image) && $image != "") {
                              echo $image;
                            } ?>" />

                  <?php if (isset($image_err) && !empty($image_err)) {
                    foreach ($image_err as $key => $error) {
                      echo "<div class=\"error-msg\"></div>";
                    }
                  } ?>

                  <?php if (isset($articles->image) && $articles->image != "") { ?>

                    <br>

                    <img src="<?php echo $this->config->item("photo_url"); ?><?php echo $articles->image; ?>" alt="pic" width="50" height="50" />

                  <?php } ?>

                </div>

                <div class="col-sm-3">

                </div>

              </div>

              <!-- Image End -->              <div class="form-group">
                <div class="col-sm-3">
                </div>

                <div class="col-sm-6 m-3">
                  <button type="reset" class="btn btn-default ">Reset</button>
                  <button type="submit" class="btn btn-info ">Submit</button>
                </div>

                <div class="col-sm-3">
                </div>
              </div>
            </div>
            <!-- /.box-body -->

            <div class="box-footer">
            </div>
            <!-- /.box-footer -->
          </form>
        </div>
        <!-- /.box -->

        <br><br><br><br>
      </div>
      <!-- EO : content  -->
      <!-- ...................................................................... -->
    </div>
  </div>
</div>

<?php $this->load->view('admin/template/footer'); ?>