## Description

New Branch From romi/revision2

## Change Log

# 5 Feb 2025

[x] Change Banner Layout
[x] Add Flowing Path Animation
[x] Change Color Banner
[x] Add Button Element Appointment for Mobile Version
[x] Change position between Youtube and Tagline (invert)
[x] Change Grid Our Projects desktop version
[x] Scale Let's Talk more full screen
[x] Optimize Responsive
